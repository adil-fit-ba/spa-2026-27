#pragma once

#include "Lista.h"

// Sekvencijalna lista (array list): elementi su u dinamickom nizu N[0..brojac-1].
// dodaj i ukloni rade na KRAJU niza, pa se nista ne pomjera -> O(1).
template <class Tip>
class ListaSekv : public Lista<Tip>
{
private:
	Tip* N;
	int brojac;
	int max;

	// prosirenje niza (dupliranje kapaciteta) kad se niz napuni
	void prosiriListu()
	{
		int newMax = max * 2;
		Tip* novi = new Tip[newMax];
		for (int i = 0; i < brojac; i++)
		{
			novi[i] = N[i];
		}
		delete[] N;
		N = novi;
		max = newMax;
		cout << "  LISTA: prosirenje - novi kapacitet je " << newMax << endl;
	}

public:
	ListaSekv(int max = 10)
	{
		if (max < 1)
			max = 1; // sa max = 0 dupliranje bi uvijek davalo 0
		this->max = max;
		N = new Tip[max];
		brojac = 0;
	}

	void dodaj(Tip v) override
	{
		if (brojac == max)
		{
			prosiriListu();
		}

		N[brojac] = v;
		brojac++;
	}

	Tip ukloni() override
	{
		if (isPrazan())
		{
			throw runtime_error("ListaSekv::ukloni - lista je prazna");
		}

		brojac--;
		return N[brojac];
	}

	bool isPrazan() override
	{
		return brojac == 0;
	}

	int count() override
	{
		return brojac;
	}

	Tip& get(int i) override
	{
		if (i < 0 || i >= brojac)
		{
			throw runtime_error("ListaSekv::get - indeks izvan opsega");
		}

		return N[i];
	}

	bool sadrzi(Tip v) override
	{
		for (int i = 0; i < brojac; i++)
		{
			if (N[i] == v)
				return true;
		}
		return false;
	}

	int ocistiSve() override
	{
		// niz ostaje alociran - dovoljno je "zaboraviti" elemente
		int obrisano = brojac;
		brojac = 0;
		return obrisano;
	}

	void ispisi(string separator = "") override
	{
		for (int i = 0; i < brojac; i++)
		{
			cout << N[i];
			if (i < brojac - 1)
				cout << separator;
		}
		cout << endl;
	}

	~ListaSekv()
	{
		delete[] N;
	}
};
