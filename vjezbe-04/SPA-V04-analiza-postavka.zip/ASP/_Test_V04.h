#pragma once

#include <iostream>
#include <string>
#include <queue>

using namespace std;

#include "TestFramework.h"
#include "Analiza.h"
#include "Stoperica.h"
#include "ListaSekv.h"
#include "ListaPov.h"
#include "RedSekv.h"
#include "RedPov.h"

// ============================================================
//  Testovi: broj izvrsavanja tijela petlje = formula s papira.
//  Formula se izvodi rucno (tabela i, j, broj izvrsavanja), pa se ovdje provjerava.
// ============================================================
void testObrasciPetlji()
{
	separator("TESTOVI [PETLJE] - broj izvrsavanja tijela petlje");

	test("[PETLJE] i++ do n: n = 0 -> 0", [] { return petljaLinearna(0) == 0; });
	test("[PETLJE] i++ do n: n = 10 -> 10", [] { return petljaLinearna(10) == 10; });
	test("[PETLJE] i++ do n: n = 1000 -> 1000", [] { return petljaLinearna(1000) == 1000; });

	test("[PETLJE] i += 2: n = 10 -> 5", [] { return petljaKorakDva(10) == 5; });
	test("[PETLJE] i += 2: n = 11 -> 6 (gornji dio od n/2)", [] { return petljaKorakDva(11) == 6; });
	test("[PETLJE] i += 2: n = 1000 -> 500", [] { return petljaKorakDva(1000) == 500; });

	test("[PETLJE] i-- od n do 1: n = 1 -> 0", [] { return petljaUnazad(1) == 0; });
	test("[PETLJE] i-- od n do 1: n = 10 -> 9 (n - 1)", [] { return petljaUnazad(10) == 9; });
	test("[PETLJE] i-- od n do 1: n = 1000 -> 999", [] { return petljaUnazad(1000) == 999; });

	test("[PETLJE] i *= 2: n = 1 -> 0", [] { return petljaPutaDva(1) == 0; });
	test("[PETLJE] i *= 2: n = 1000 -> 10 (log2 1000 = 9,97, zaokruzeno navise)", [] { return petljaPutaDva(1000) == 10; });
	test("[PETLJE] i *= 2: n = 1024 -> 10", [] { return petljaPutaDva(1024) == 10; });
	test("[PETLJE] i *= 2: n = 1025 -> 11", [] { return petljaPutaDva(1025) == 11; });

	test("[PETLJE] ugnijezdjena n x n: n = 0 -> 0", [] { return petljaUgnijezdjena(0) == 0; });
	test("[PETLJE] ugnijezdjena n x n: n = 10 -> 100", [] { return petljaUgnijezdjena(10) == 100; });
	test("[PETLJE] ugnijezdjena n x n: n = 300 -> 90000 (n^2)", [] { return petljaUgnijezdjena(300) == 90000; });

	test("[PETLJE] j < i: n = 4 -> 6 (0 + 1 + 2 + 3)", [] { return petljaZavisna(4) == 6; });
	test("[PETLJE] j < i: n = 10 -> 45", [] { return petljaZavisna(10) == 45; });
	test("[PETLJE] j < i: n = 1000 -> 499500 (n(n-1)/2)", [] { return petljaZavisna(1000) == 499500; });

	test("[PETLJE] p += i: n = 10 -> 5 (p = 1, 3, 6, 10, 15)", [] { return petljaKorijen(10) == 5; });
	test("[PETLJE] p += i: n = 1000 -> 45", [] { return petljaKorijen(1000) == 45; });
	test("[PETLJE] p += i: n = 1000000 -> 1414 (oko korijena iz 2n)", [] { return petljaKorijen(1000000) == 1414; });

	test("[PETLJE] j *= 2 do p = log2 n: n = 1000 -> 4", [] { return petljaLogLog(1000) == 4; });
	test("[PETLJE] j *= 2 do p = log2 n: n = 65536 -> 4", [] { return petljaLogLog(65536) == 4; });
	test("[PETLJE] j *= 2 do p = log2 n: n = 1000000 -> 5", [] { return petljaLogLog(1000000) == 5; });
}

void testRastNiza()
{
	separator("TESTOVI [RAST] - kopiranja pri prosirenju niza (pocetni kapacitet 1)");

	test("[RAST] + 1: n = 1000 -> 499500 kopiranja (n(n-1)/2)", [] {
		return kopiranjaPriRastu(1000, Rast::PlusJedan) == 499500; });
	test("[RAST] x 2: n = 1000 -> 1023 (1 + 2 + 4 + ... + 512)", [] {
		return kopiranjaPriRastu(1000, Rast::PutaDva) == 1023; });
	test("[RAST] x 2: n = 1025 -> 2047", [] {
		return kopiranjaPriRastu(1025, Rast::PutaDva) == 2047; });
	test("[RAST] x 1,5: n = 1000 -> 2137", [] {
		return kopiranjaPriRastu(1000, Rast::PutaJedanIPo) == 2137; });
	test("[RAST] x 1,5 i x 2: manje od 3n kopiranja za n = 100000", [] {
		return kopiranjaPriRastu(100000, Rast::PutaJedanIPo) < 300000 && kopiranjaPriRastu(100000, Rast::PutaDva) < 300000; });
}

// ============================================================
//  Mjerenje (a posteriori) - nije automatski test.
//  Pokrenuti i u Debug i u Release konfiguraciji i uporediti.
// ============================================================
void demoMjerenje()
{
#ifdef _DEBUG
	separator("MJERENJE - Debug (bez optimizacije; Release je visestruko brzi)");
#else
	separator("MJERENJE - Release");
#endif
	const int nRed = 100000;
	double tSekv = medijanMs([&] {
		RedSekv<int> r(nRed);
		for (int i = 0; i < nRed; i++) r.dodaj(i);
		for (int i = 0; i < nRed; i++) r.ukloni();
	}, 5);
	double tPov = medijanMs([&] {
		RedPov<int> r;
		for (int i = 0; i < nRed; i++) r.dodaj(i);
		for (int i = 0; i < nRed; i++) r.ukloni();
	}, 5);
	double tStd = medijanMs([&] {
		queue<int> r;
		for (int i = 0; i < nRed; i++) r.push(i);
		for (int i = 0; i < nRed; i++) r.pop();
	}, 5);
	cout << "  " << nRed << " x dodaj + " << nRed << " x ukloni (medijan 5 mjerenja):" << endl;
	cout << "    RedSekv:    " << tSekv << " ms" << endl;
	cout << "    RedPov:     " << tPov << " ms" << endl;
	cout << "    std::queue: " << tStd << " ms" << endl;

	const int nGet = 5000;
	ListaSekv<int> ls(nGet);
	ListaPov<int> lp;
	for (int i = 0; i < nGet; i++) { ls.dodaj(i); lp.dodaj(i); }
	long long zbir = 0;
	double tLs = medijanMs([&] { for (int i = 0; i < nGet; i++) zbir += ls.get(i); }, 5);
	double tLp = medijanMs([&] { for (int i = 0; i < nGet; i++) zbir += lp.get(i); }, 5);
	cout << "  zbir preko get(i), n = " << nGet << " (medijan 5 mjerenja):" << endl;
	cout << "    ListaSekv:  " << tLs << " ms   (get je O(1), petlja O(n))" << endl;
	cout << "    ListaPov:   " << tLp << " ms   (get(i) obilazi i cvorova, petlja O(n^2))" << endl;
	cout << "  (kontrolni zbir " << zbir % 1000 << ")" << endl;
}

void _test_V04()
{
	testObrasciPetlji();
	testRastNiza();

	try { demoMjerenje(); }
	catch (const exception& e) { cout << "  izuzetak: " << e.what() << endl; }

	rezultatTestova();
}
