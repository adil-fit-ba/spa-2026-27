#pragma once

#include <chrono>
#include <vector>
#include <algorithm>
using namespace std;

// ============================================================
//  DATO: mjerenje vremena (analiza a posteriori).
//  steady_clock ne skace kad se promijeni sat racunara.
//  Mjeri se vise puta, a prikazuje MEDIJAN (jedno mjerenje nije dovoljno).
// ============================================================
template <class Fn>
double mjeriMs(Fn fn)
{
	auto pocetak = chrono::steady_clock::now();
	fn();
	auto kraj = chrono::steady_clock::now();
	chrono::duration<double, milli> t = kraj - pocetak;
	return t.count();
}

double medijan(vector<double> v)
{
	sort(v.begin(), v.end());
	size_t m = v.size() / 2;
	return v.size() % 2 ? v[m] : (v[m - 1] + v[m]) / 2;
}

template <class Fn>
double medijanMs(Fn fn, int ponavljanja = 10)
{
	vector<double> t;
	for (int i = 0; i < ponavljanja; i++)
		t.push_back(mjeriMs(fn));
	return medijan(t);
}
