#pragma once

#include <iostream>
#include <string>
#include <stdexcept>
using namespace std;

// Red (queue) - FIFO: prvi dodani element se prvi uklanja.
// Dodaje se na KRAJ, uklanja se s POCETKA (enqueue / dequeue).
template <class Tip>
class Red
{
public:
	// dodaje element na kraj reda
	virtual void dodaj(Tip v) = 0;

	// uklanja i vraca element s pocetka reda; na praznom redu baca izuzetak
	virtual Tip ukloni() = 0;

	virtual bool isPrazan() = 0;

	// broj elemenata u redu
	virtual int count() = 0;

	// trazi element (bez uklanjanja) - treba nam kasnije za BFS
	virtual bool sadrzi(Tip v) = 0;

	// brise sve elemente i vraca broj obrisanih
	virtual int ocistiSve() = 0;

	// ispisuje elemente od POCETKA prema KRAJU, odvojene separatorom
	virtual void ispisi(string separator = "") = 0;

	// get(i) namjerno ne postoji: kod reda se pristupa samo pocetku i kraju

	virtual ~Red() {}
};
