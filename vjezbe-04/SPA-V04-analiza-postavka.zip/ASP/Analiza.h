#pragma once

#include <stdexcept>
using namespace std;

// ============================================================
//  V04 - analiza algoritama: metoda brojanja koraka (frequency count).
//  Svaka funkcija izvrsava petlju iz komentara i vraca koliko se puta
//  izvrsilo TIJELO petlje (kod ugnijezdjenih: tijelo unutrasnje petlje).
//  Testovi porede rezultat s formulom koju treba izvesti na papiru.
// ============================================================

// for (i = 0; i < n; i++)
long long petljaLinearna(int n)
{
	// TODO: Studenti implementiraju
	// Napisati petlju iz komentara iznad i brojati izvrsavanja tijela petlje.
	throw runtime_error("petljaLinearna() nije implementiran");
}

// for (i = 0; i < n; i += 2)
long long petljaKorakDva(int n)
{
	// TODO: Studenti implementiraju
	// Napisati petlju iz komentara iznad i brojati izvrsavanja tijela petlje.
	throw runtime_error("petljaKorakDva() nije implementiran");
}

// for (i = n; i > 1; i--)
long long petljaUnazad(int n)
{
	// TODO: Studenti implementiraju
	// Napisati petlju iz komentara iznad i brojati izvrsavanja tijela petlje.
	throw runtime_error("petljaUnazad() nije implementiran");
}

// for (i = 1; i < n; i *= 2)
long long petljaPutaDva(int n)
{
	// TODO: Studenti implementiraju
	// Napisati petlju iz komentara iznad i brojati izvrsavanja tijela petlje.
	throw runtime_error("petljaPutaDva() nije implementiran");
}

// for (i = 0; i < n; i++)
//     for (j = 0; j < n; j++)
long long petljaUgnijezdjena(int n)
{
	// TODO: Studenti implementiraju
	// Napisati petlju iz komentara iznad i brojati izvrsavanja tijela petlje.
	throw runtime_error("petljaUgnijezdjena() nije implementiran");
}

// for (i = 0; i < n; i++)
//     for (j = 0; j < i; j++)      <- unutrasnja zavisi od vanjske
long long petljaZavisna(int n)
{
	// TODO: Studenti implementiraju
	// Napisati petlju iz komentara iznad i brojati izvrsavanja tijela petlje.
	throw runtime_error("petljaZavisna() nije implementiran");
}

// p = 0;
// for (i = 1; p <= n; i++)
//     p = p + i;                    <- p = 1, 3, 6, 10, ...
long long petljaKorijen(int n)
{
	// TODO: Studenti implementiraju
	// Napisati petlju iz komentara iznad i brojati izvrsavanja tijela petlje.
	throw runtime_error("petljaKorijen() nije implementiran");
}

// p = 0;
// for (i = 1; i < n; i *= 2)
//     p++;
// for (j = 1; j < p; j *= 2)        <- broji se samo ova petlja
long long petljaLogLog(int n)
{
	// TODO: Studenti implementiraju
	// Napisati petlju iz komentara iznad i brojati izvrsavanja tijela petlje.
	throw runtime_error("petljaLogLog() nije implementiran");
}

// ============================================================
//  Rast niza: koliko se elemenata KOPIRA kad se n elemenata dodaje
//  u niz pocetnog kapaciteta 1 (kao prosiriListu: kad je niz pun,
//  alocira se veci i kopira se svih brojac elemenata).
// ============================================================
enum class Rast { PlusJedan, PutaJedanIPo, PutaDva };

// DATO: novi kapacitet za izabranu strategiju
long long noviKapacitet(long long max, Rast rast)
{
	if (rast == Rast::PlusJedan)
		return max + 1;
	if (rast == Rast::PutaDva)
		return max * 2;
	long long dodatak = max / 2; // x 1,5 (najmanje + 1)
	return max + (dodatak > 0 ? dodatak : 1);
}

long long kopiranjaPriRastu(int n, Rast rast)
{
	// TODO: Studenti implementiraju
	// max = 1, brojac = 0, kopirano = 0; dodati n elemenata jedan po jedan.
	// Kad je brojac == max: kopirano += brojac, pa max = noviKapacitet(max, rast) (DATO).
	throw runtime_error("kopiranjaPriRastu() nije implementiran");
}
