#include <iostream>
using namespace std;

#include "_Test_V00.h"
#include "_Test_V01.h"
#include "_Test_V02.h"
#include "_Test_V03.h"
#include "_Test_V04.h"

int main()
{
	// prethodne vjezbe - ukljuciti po potrebi
	//_test_V00();
	//_test_V01();
	//_test_V02();

	//_test_V03();

	_test_V04();

	return 0;
}
