#pragma once

#include <iostream>
using namespace std;

// Cvor povezane liste: 2 bloka u memoriji - podatak (info) i adresa sljedeceg cvora (next).
template <class Tip>
struct Cvor
{
	Tip info;
	Cvor<Tip>* next;

	Cvor(Tip info, Cvor<Tip>* next) : info(info)
	{
		this->next = next;
	}
};
