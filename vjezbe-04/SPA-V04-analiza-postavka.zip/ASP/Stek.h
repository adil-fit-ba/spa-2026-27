#pragma once

#include <iostream>
#include <string>
#include <stdexcept>
using namespace std;

// Stek (stack) - LIFO: zadnji dodani element se prvi uklanja.
// "Vrh" je apstraktan pojam: kod StekSekv je to N[brojac-1], kod StekPov cvor "prvi".
// Imena push/pop su standardna i koriste se u ispitnim zadacima.
template <class Tip>
class Stek
{
public:
	// dodaje element na vrh
	virtual void push(Tip v) = 0;

	// uklanja i vraca element s vrha; na praznom steku baca izuzetak
	virtual Tip pop() = 0;

	virtual bool isPrazan() = 0;

	// broj elemenata na steku
	virtual int count() = 0;

	// trazi element (bez uklanjanja) - treba nam kasnije za DFS/BFS
	virtual bool sadrzi(Tip v) = 0;

	// brise sve elemente i vraca broj obrisanih
	virtual int ocistiSve() = 0;

	// ispisuje elemente od VRHA prema DNU, odvojene separatorom
	virtual void ispisi(string separator = "") = 0;

	// get(i) namjerno ne postoji: kod steka se pristupa samo vrhu

	virtual ~Stek() {}
};
