#pragma once

#include "Stek.h"
#include "Cvor.h"

// Stek nad povezanom listom - isti kod kao ListaPov, bez get(i).
// Vrh je cvor "prvi": push i pop rade na pocetku liste, bez obilaska -> O(1).
//
//   prvi -> [30|*] -> [20|*] -> [10|nullptr]      (push redom 10, 20, 30; vrh = 30)
template <class Tip>
class StekPov : public Stek<Tip>
{
private:
	Cvor<Tip>* prvi;
	int brojac;

public:
	StekPov()
	{
		prvi = nullptr;
		brojac = 0;
	}

	void push(Tip v) override
	{
		// novi cvor pokazuje na dosadasnji vrh, pa tek onda postaje vrh
		Cvor<Tip>* novi = new Cvor<Tip>(v, prvi);
		prvi = novi;
		brojac++;
	}

	Tip pop() override
	{
		// 1. provjera: iz praznog steka nema sta ukloniti
		if (isPrazan())
		{
			throw runtime_error("StekPov::pop - stek je prazan");
		}

		// 2. umanjenje brojaca
		brojac--;

		// 3. ukloni cvor iz povezane liste - adresu prvo sacuvaj u t
		Cvor<Tip>* t = prvi;
		prvi = prvi->next;

		// 4. sacuvaj vrijednost PRIJE dealokacije, pa dealociraj cvor
		Tip x = t->info;
		delete t;

		// 5. vrati uklonjeni element
		return x;
	}

	bool isPrazan() override
	{
		return prvi == nullptr;
	}

	int count() override
	{
		return brojac;
	}

	bool sadrzi(Tip v) override
	{
		Cvor<Tip>* t = prvi;
		while (t != nullptr)
		{
			if (t->info == v)
				return true;
			t = t->next;
		}
		return false;
	}

	int ocistiSve() override
	{
		// svaki cvor mora biti dealociran - inace curenje memorije
		int b = 0;
		while (!isPrazan())
		{
			pop();
			b++;
		}
		return b;
	}

	void ispisi(string separator = "") override
	{
		// prvi je vrh, pa je redoslijed vec od vrha prema dnu
		Cvor<Tip>* t = prvi;
		while (t != nullptr)
		{
			cout << t->info;
			if (t->next != nullptr)
				cout << separator;
			t = t->next;
		}
		cout << endl;
	}

	~StekPov()
	{
		while (prvi != nullptr)
		{
			Cvor<Tip>* t = prvi;
			prvi = prvi->next;
			delete t;
		}
	}
};
