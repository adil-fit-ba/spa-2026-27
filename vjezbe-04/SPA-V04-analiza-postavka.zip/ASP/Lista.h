#pragma once

#include <iostream>
#include <string>
#include <stdexcept>
using namespace std;

// Apstraktna klasa (interfejs) - zajednicka za ListaSekv i ListaPov.
// Ista imena metoda koristimo kasnije za Stek, Red i PrioritetniRed.
template <class Tip>
class Lista
{
public:
	// dodaje element u listu
	virtual void dodaj(Tip v) = 0;

	// uklanja i vraca ZADNJE DODANI element; na praznoj listi baca izuzetak
	virtual Tip ukloni() = 0;

	virtual bool isPrazan() = 0;

	// broj elemenata u listi
	virtual int count() = 0;

	// element na poziciji i (0 = prvi u fizickom rasporedu); neispravan i -> izuzetak
	virtual Tip& get(int i) = 0;

	virtual bool sadrzi(Tip v) = 0;

	// brise sve elemente i vraca broj obrisanih
	virtual int ocistiSve() = 0;

	// ispisuje elemente redom kojim su smjesteni, odvojene separatorom
	virtual void ispisi(string separator = "") = 0;

	// virtualni destruktor: "delete lista" preko Lista<Tip>* poziva destruktor konkretne klase
	virtual ~Lista() {}
};
