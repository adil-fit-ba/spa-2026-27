#pragma once

#include <iostream>
#include <string>

using namespace std;

#include "TestFramework.h"
#include "Osoba.h"
#include "Red.h"
#include "RedSekv.h"
#include "RedPov.h"
#include "StekPov.h"

// ============================================================
//  Zajednicki testovi - vrijede za OBJE implementacije.
//  R je konkretna klasa: RedSekv<int> ili RedPov<int>.
// ============================================================
template <class R>
void testRedZajednicko(string oznaka)
{
	separator("TESTOVI " + oznaka);

	test(oznaka + " novi red je prazan", [] {
		R r; return r.isPrazan() == true; });

	test(oznaka + " count() = 0 na praznom redu", [] {
		R r; return r.count() == 0; });

	test(oznaka + " nije prazan nakon dodaj", [] {
		R r; r.dodaj(10); return r.isPrazan() == false; });

	test(oznaka + " count() = 3 nakon 3x dodaj", [] {
		R r; r.dodaj(10); r.dodaj(20); r.dodaj(30);
		return r.count() == 3; });

	test(oznaka + " ukloni() vraca 10 (prvi dodan - FIFO)", [] {
		R r; r.dodaj(10); r.dodaj(20); r.dodaj(30);
		return r.ukloni() == 10; });

	test(oznaka + " ukloni() zatim vraca 20, pa 30", [] {
		R r; r.dodaj(10); r.dodaj(20); r.dodaj(30);
		r.ukloni(); return r.ukloni() == 20 && r.ukloni() == 30; });

	test(oznaka + " prazan nakon svih ukloni()", [] {
		R r; r.dodaj(10); r.dodaj(20); r.dodaj(30);
		r.ukloni(); r.ukloni(); r.ukloni();
		return r.isPrazan() == true && r.count() == 0; });

	test(oznaka + " ukloni() na praznom redu baca izuzetak", [] {
		R r; r.dodaj(1); r.ukloni();
		bool bacen = false;
		try { r.ukloni(); }
		catch (...) { bacen = true; }
		return bacen; });

	test(oznaka + " dodaj nakon praznjenja: red ponovo radi", [] {
		R r; r.dodaj(1); r.ukloni(); r.dodaj(2); r.dodaj(3);
		return r.count() == 2 && r.ukloni() == 2 && r.ukloni() == 3; });

	test(oznaka + " naizmjenicno dodaj/ukloni cuva FIFO", [] {
		R r; r.dodaj(1); r.dodaj(2); r.ukloni(); r.dodaj(3); r.ukloni(); r.dodaj(4);
		return r.ukloni() == 3 && r.ukloni() == 4 && r.isPrazan(); });

	test(oznaka + " sadrzi(20) = true", [] {
		R r; r.dodaj(10); r.dodaj(20); r.dodaj(30);
		return r.sadrzi(20) == true; });

	test(oznaka + " sadrzi(99) = false", [] {
		R r; r.dodaj(10); r.dodaj(20); r.dodaj(30);
		return r.sadrzi(99) == false; });

	test(oznaka + " sadrzi(10) = false nakon ukloni()", [] {
		R r; r.dodaj(10); r.dodaj(20); r.dodaj(30);
		r.ukloni(); return r.sadrzi(10) == false && r.sadrzi(30) == true; });

	test(oznaka + " ocistiSve() vraca 4 (broj obrisanih)", [] {
		R r; r.dodaj(1); r.dodaj(2); r.dodaj(3); r.dodaj(4);
		return r.ocistiSve() == 4; });

	test(oznaka + " prazan nakon ocistiSve()", [] {
		R r; r.dodaj(1); r.dodaj(2); r.dodaj(3); r.dodaj(4);
		r.ocistiSve(); return r.isPrazan() == true && r.count() == 0; });

	test(oznaka + " radi i nakon ocistiSve()", [] {
		R r; r.dodaj(1); r.dodaj(2); r.ocistiSve(); r.dodaj(5); r.dodaj(6);
		return r.count() == 2 && r.ukloni() == 5 && r.ukloni() == 6; });

	test(oznaka + " 100 elemenata: count() = 100", [] {
		R r;
		for (int i = 0; i < 100; i++) r.dodaj(i);
		return r.count() == 100; });

	test(oznaka + " 100 elemenata: ukloni() vraca 0, 1 ... 99 (FIFO)", [] {
		R r;
		for (int i = 0; i < 100; i++) r.dodaj(i);
		for (int i = 0; i < 100; i++)
			if (r.ukloni() != i) return false;
		return r.isPrazan(); });
}

// ============================================================
//  Specificno za RedSekv: kruzni niz i prosirenje
// ============================================================
void testRedSekvSpecificno()
{
	separator("TESTOVI [RED-SEKV] - kruzni niz");

	test("[RED-SEKV] kruzno: kraj prelazi s kraja niza na pocetak (bez prosirenja)", [] {
		RedSekv<int> r(4);
		r.dodaj(1); r.dodaj(2); r.dodaj(3);
		r.ukloni(); r.ukloni();          // pocetak = 2
		r.dodaj(4); r.dodaj(5); r.dodaj(6); // kraj: 3 -> 0 -> 1 -> 2
		return r.count() == 4; });

	test("[RED-SEKV] kruzno: redoslijed 3, 4, 5, 6 ocuvan", [] {
		RedSekv<int> r(4);
		r.dodaj(1); r.dodaj(2); r.dodaj(3);
		r.ukloni(); r.ukloni();
		r.dodaj(4); r.dodaj(5); r.dodaj(6);
		return r.ukloni() == 3 && r.ukloni() == 4 && r.ukloni() == 5 && r.ukloni() == 6; });

	test("[RED-SEKV] kruzno: sadrzi() vidi elemente iza prelaza", [] {
		RedSekv<int> r(4);
		r.dodaj(1); r.dodaj(2); r.dodaj(3);
		r.ukloni(); r.ukloni();
		r.dodaj(4); r.dodaj(5);
		return r.sadrzi(5) == true && r.sadrzi(1) == false; });

	test("[RED-SEKV] prosirenje obicnog (neprelomljenog) reda: count() = 5", [] {
		RedSekv<int> r(2);
		for (int i = 1; i <= 5; i++) r.dodaj(i * 10);
		return r.count() == 5 && r.ukloni() == 10; });

	test("[RED-SEKV] prosirenje PRELOMLJENOG reda cuva redoslijed", [] {
		RedSekv<int> r(4);
		r.dodaj(1); r.dodaj(2); r.dodaj(3); r.dodaj(4);
		r.ukloni(); r.ukloni();          // pocetak = 2
		r.dodaj(5); r.dodaj(6);          // pun, prelomljen: [5][6][3][4]
		r.dodaj(7);                      // prosirenje
		return r.ukloni() == 3 && r.ukloni() == 4 && r.ukloni() == 5
			&& r.ukloni() == 6 && r.ukloni() == 7 && r.isPrazan(); });
}

// ============================================================
//  Specificno za RedPov: pokazivac kraj
// ============================================================
void testRedPovSpecificno()
{
	separator("TESTOVI [RED-POV] - pokazivac kraj");

	test("[RED-POV] nakon uklanjanja zadnjeg, dodaj ponovo postavlja pocetak i kraj", [] {
		RedPov<int> r; r.dodaj(1); r.ukloni();
		r.dodaj(2); r.dodaj(3);
		return r.ukloni() == 2 && r.ukloni() == 3 && r.isPrazan(); });
}

// ============================================================
//  Integracija: red + stek - obrtanje redoslijeda
// ============================================================
void testRedStekIntegracija()
{
	separator("INTEGRACIJA [INT] - red + stek");

	test("[INT] red -> stek -> red obrce redoslijed (1,2,3 -> 3,2,1)", [] {
		RedPov<int> r; StekPov<int> s;
		r.dodaj(1); r.dodaj(2); r.dodaj(3);
		while (!r.isPrazan()) s.push(r.ukloni());
		while (!s.isPrazan()) r.dodaj(s.pop());
		return r.ukloni() == 3 && r.ukloni() == 2 && r.ukloni() == 1; });

	test("[INT] isto sa RedSekv (kruzni niz)", [] {
		RedSekv<int> r(2); StekPov<int> s;
		r.dodaj(1); r.dodaj(2); r.dodaj(3);
		while (!r.isPrazan()) s.push(r.ukloni());
		while (!s.isPrazan()) r.dodaj(s.pop());
		return r.ukloni() == 3 && r.ukloni() == 2 && r.ukloni() == 1; });
}

// ============================================================
//  Vizuelna provjera ispisi() - nije automatski test.
//  Oba reda ispisuju ISTO: od pocetka prema kraju.
// ============================================================
void ispisiRedVizuelno()
{
	separator("ispisi() - vizuelna provjera");
	try
	{
		RedSekv<int> r(4);
		r.dodaj(10); r.dodaj(20); r.dodaj(30);
		r.ukloni();
		r.dodaj(40); r.dodaj(50); // kraj prelazi na pocetak niza
		cout << "  [RED-SEKV] Ocekivano: 20, 30, 40, 50" << endl;
		cout << "             Dobijeno:  ";
		r.ispisi(", ");
	}
	catch (...) { cout << "(nije implementirano)" << endl; }

	try
	{
		RedPov<int> p; p.dodaj(10); p.dodaj(20); p.dodaj(30);
		cout << "  [RED-POV]  Ocekivano: 10, 20, 30" << endl;
		cout << "             Dobijeno:  ";
		p.ispisi(", ");
	}
	catch (...) { cout << "(nije implementirano)" << endl; }
}

// ============================================================
//  Demo: ista funkcija radi s oba reda preko pokazivaca na interfejs
// ============================================================
void demoRedOsobe(Red<Osoba*>* red, string naziv)
{
	cout << "\n--- DEMO " << naziv << " (Red<Osoba*>*) ---" << endl;

	Osoba* p21 = new Osoba(21, "p21");
	Osoba* p22 = new Osoba(22, "p22");
	Osoba* p23 = new Osoba(23, "p23");

	red->dodaj(p21);
	red->dodaj(p22);
	red->dodaj(p23);

	cout << "  ispisi (pocetak -> kraj): ";
	red->ispisi("; ");

	while (!red->isPrazan())
	{
		cout << "  ukloni {" << red->ukloni() << "}" << endl;
	}

	// red cuva samo ADRESE osoba - objekte brisemo mi
	delete p21; delete p22; delete p23;
	delete red; // virtualni destruktor u Red -> poziva ~RedSekv / ~RedPov
}

void _test_V03()
{
	testRedZajednicko<RedSekv<int>>("[RED-SEKV]");
	testRedSekvSpecificno();

	testRedZajednicko<RedPov<int>>("[RED-POV]");
	testRedPovSpecificno();

	testRedStekIntegracija();

	ispisiRedVizuelno();

	separator("DEMO - Red<Osoba*>");
	try { demoRedOsobe(new RedSekv<Osoba*>, "RedSekv"); }
	catch (const exception& e) { cout << "  izuzetak: " << e.what() << endl; }
	try { demoRedOsobe(new RedPov<Osoba*>, "RedPov"); }
	catch (const exception& e) { cout << "  izuzetak: " << e.what() << endl; }

	rezultatTestova();
}
