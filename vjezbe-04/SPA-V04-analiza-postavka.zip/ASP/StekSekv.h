#pragma once

#include "Stek.h"

// Stek nad nizom - isti kod kao ListaSekv, bez get(i).
// Vrh je na KRAJU niza (N[brojac-1]), pa push i pop nista ne pomjeraju -> O(1).
//
//   N: [10][20][30][  ][  ]      brojac = 3, max = 5, vrh = N[2] = 30
template <class Tip>
class StekSekv : public Stek<Tip>
{
private:
	Tip* N;
	int brojac;
	int max;

	// prosirenje niza (dupliranje kapaciteta) kad se niz napuni
	void prosiriListu()
	{
		int newMax = max * 2;
		Tip* novi = new Tip[newMax];
		for (int i = 0; i < brojac; i++)
		{
			novi[i] = N[i];
		}
		delete[] N; // stari niz se mora dealocirati
		N = novi;
		max = newMax;
		cout << "  STEK: prosirenje - novi kapacitet je " << newMax << endl;
	}

public:
	StekSekv(int max = 10)
	{
		if (max < 1)
			max = 1; // sa max = 0 dupliranje bi uvijek davalo 0
		this->max = max;
		N = new Tip[max];
		brojac = 0;
	}

	void push(Tip v) override
	{
		if (brojac == max)
		{
			prosiriListu();
		}

		N[brojac] = v;
		brojac++;
	}

	Tip pop() override
	{
		if (isPrazan())
		{
			throw runtime_error("StekSekv::pop - stek je prazan");
		}

		brojac--;
		return N[brojac];
	}

	bool isPrazan() override
	{
		return brojac == 0;
	}

	int count() override
	{
		return brojac;
	}

	bool sadrzi(Tip v) override
	{
		for (int i = 0; i < brojac; i++)
		{
			if (N[i] == v)
				return true;
		}
		return false;
	}

	int ocistiSve() override
	{
		// niz ostaje alociran - dovoljno je "zaboraviti" elemente
		int obrisano = brojac;
		brojac = 0;
		return obrisano;
	}

	void ispisi(string separator = "") override
	{
		// od vrha (zadnji dodani) prema dnu
		for (int i = brojac - 1; i >= 0; i--)
		{
			cout << N[i];
			if (i > 0)
				cout << separator;
		}
		cout << endl;
	}

	~StekSekv()
	{
		delete[] N;
	}
};
