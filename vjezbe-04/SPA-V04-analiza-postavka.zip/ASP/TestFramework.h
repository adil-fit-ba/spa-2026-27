#pragma once

#include <iostream>
#include <string>
#include <stdexcept>
using namespace std;

// ============================================================
//  Mini test framework - isti kao u ispitnim starterima.
//  Svaka tvrdnja se izvrsava ODVOJENO i sama hvata izuzetke,
//  pa jedna neimplementirana metoda ne rusi ostale testove.
// ============================================================
int ukupnoTestova = 0;
int prosloTestova = 0;

template <typename Fn>
void test(const string& opis, Fn fn)
{
	ukupnoTestova++;
	try
	{
		if (fn())
		{
			prosloTestova++;
			cout << "  [PASS] " << opis << endl;
		}
		else
		{
			cout << "  [FAIL] " << opis << " <<<" << endl;
		}
	}
	catch (const exception& e)
	{
		cout << "  [FAIL] " << opis << "  (izuzetak: " << e.what() << ") <<<" << endl;
	}
	catch (...)
	{
		cout << "  [FAIL] " << opis << "  (nepoznat izuzetak) <<<" << endl;
	}
}

void separator(const string& naslov)
{
	cout << "\n========================================" << endl;
	cout << "  " << naslov << endl;
	cout << "========================================" << endl;
}

void rezultatTestova()
{
	separator("REZULTAT");
	cout << "\n  Proslo: " << prosloTestova << " / " << ukupnoTestova << endl;
	if (prosloTestova == ukupnoTestova)
		cout << "\n  *** SVE PROLAZI! Svaka cast! ***" << endl;
	else
		cout << "\n  >>> Ima gresaka - pogledaj [FAIL] testove gore. <<<" << endl;
	cout << endl;
}
