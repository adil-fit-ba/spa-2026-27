#pragma once

#include "Red.h"

// Red nad nizom - KRUZNI niz.
// pocetak = indeks prvog elementa, kraj = indeks prvog SLOBODNOG mjesta.
// Kad indeks dodje do max, nastavlja od 0, pa se elementi nikad ne pomjeraju:
// dodaj i ukloni su O(1).
//
//   max = 5:  N: [40][  ][  ][20][30]    pocetak = 3, kraj = 1, brojac = 3
//             redoslijed u redu: 20, 30, 40
template <class Tip>
class RedSekv : public Red<Tip>
{
private:
	Tip* N;
	int brojac;
	int max;
	int pocetak;
	int kraj;

	// DATO: prosirenje niza (dupliranje kapaciteta).
	// Elementi se kopiraju REDOM od pocetka reda (kruzno), pa novi niz
	// pocinje od indeksa 0: pocetak = 0, kraj = brojac.
	void prosiriRed()
	{
		int newMax = max * 2;
		Tip* novi = new Tip[newMax];
		int indeks = pocetak;
		for (int i = 0; i < brojac; i++)
		{
			novi[i] = N[indeks];
			indeks++;
			if (indeks == max)
				indeks = 0;
		}
		delete[] N;
		N = novi;
		max = newMax;
		pocetak = 0;
		kraj = brojac;
		cout << "  RED: prosirenje - novi kapacitet je " << newMax << endl;
	}

public:
	RedSekv(int max = 10)
	{
		if (max < 1)
			max = 1; // sa max = 0 dupliranje bi uvijek davalo 0
		this->max = max;
		N = new Tip[max];
		brojac = 0;
		pocetak = 0;
		kraj = 0;
	}

	void dodaj(Tip v) override
	{
		if (brojac == max)
		{
			prosiriRed();
		}

		N[kraj] = v;
		kraj++;
		if (kraj == max) // kruzno: s kraja niza na pocetak
			kraj = 0;
		brojac++;
	}

	Tip ukloni() override
	{
		if (isPrazan())
		{
			throw runtime_error("RedSekv::ukloni - red je prazan");
		}

		Tip x = N[pocetak];
		pocetak++;
		if (pocetak == max) // kruzno
			pocetak = 0;
		brojac--;
		return x;
	}

	bool isPrazan() override
	{
		// pocetak == kraj vrijedi i za PRAZAN i za PUN red - zato brojac
		return brojac == 0;
	}

	int count() override
	{
		return brojac;
	}

	bool sadrzi(Tip v) override
	{
		int indeks = pocetak;
		for (int i = 0; i < brojac; i++)
		{
			if (N[indeks] == v)
				return true;
			indeks++;
			if (indeks == max)
				indeks = 0;
		}
		return false;
	}

	int ocistiSve() override
	{
		int obrisano = brojac;
		brojac = 0;
		pocetak = 0;
		kraj = 0;
		return obrisano;
	}

	void ispisi(string separator = "") override
	{
		int indeks = pocetak;
		for (int i = 0; i < brojac; i++)
		{
			cout << N[indeks];
			if (i < brojac - 1)
				cout << separator;
			indeks++;
			if (indeks == max)
				indeks = 0;
		}
		cout << endl;
	}

	~RedSekv()
	{
		delete[] N;
	}
};
