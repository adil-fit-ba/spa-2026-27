#pragma once

#include <iostream>
#include <string>

using namespace std;

#include "TestFramework.h"
#include "Cvor.h"
#include "Osoba.h"

// V00 - cvorovi rucno povezani (uvod u povezanu listu, prije klase ListaPov)
void _test_V00()
{
	separator("V00: CVOROVI (rucno povezani)");

	// c3 -> c2 -> c1 -> nullptr
	Cvor<int>* c1 = new Cvor<int>(2301, nullptr);
	Cvor<int>* c2 = new Cvor<int>(2302, c1);
	Cvor<int>* c3 = new Cvor<int>(2303, c2);

	cout << "  Obilazak od c3: ";
	Cvor<int>* t = c3;
	while (t != nullptr)
	{
		cout << t->info << " -> ";
		t = t->next;
	}
	cout << "nullptr" << endl;

	// adrese: next svakog cvora je adresa sljedeceg (vidi model memorije sa vjezbi)
	cout << "  c3 = " << c3 << ",  c3->next = " << c3->next << " (= c2)" << endl;
	cout << "  c2 = " << c2 << ",  c2->next = " << c2->next << " (= c1)" << endl;
	cout << "  c1 = " << c1 << ",  c1->next = " << c1->next << " (nullptr)" << endl;
	cout << "  sizeof(int) = " << sizeof(int) << ", sizeof(int*) = " << sizeof(int*)
		<< ", sizeof(Cvor<int>) = " << sizeof(Cvor<int>) << endl;

	delete c3;
	delete c2;
	delete c1;

	// Cvor moze cuvati bilo koji tip - i pokazivac na objekat
	Osoba* p1 = new Osoba(1623, "M. Hadzic");
	Osoba* p2 = new Osoba(2369, "I. Beslic");
	Cvor<Osoba*>* co1 = new Cvor<Osoba*>(p1, nullptr);
	Cvor<Osoba*>* co2 = new Cvor<Osoba*>(p2, co1);

	cout << "  Osobe: " << co2->info << " -> " << co2->next->info << " -> nullptr" << endl;

	delete co2;
	delete co1;
	delete p2;
	delete p1;
}
