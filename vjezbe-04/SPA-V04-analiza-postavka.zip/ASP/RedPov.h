#pragma once

#include "Red.h"
#include "Cvor.h"

// Red nad povezanom listom - DVA pokazivaca: pocetak i kraj.
// dodaj ide iza kraja, ukloni skida pocetak; nijedna operacija ne obilazi listu -> O(1).
//
//   pocetak -> [10|*] -> [20|*] -> [30|nullptr] <- kraj      (dodano redom 10, 20, 30)
template <class Tip>
class RedPov : public Red<Tip>
{
private:
	Cvor<Tip>* pocetak;
	Cvor<Tip>* kraj;
	int brojac;

public:
	RedPov()
	{
		pocetak = nullptr;
		kraj = nullptr;
		brojac = 0;
	}

	void dodaj(Tip v) override
	{
		// novi cvor je posljednji, pa mu je next = nullptr
		Cvor<Tip>* novi = new Cvor<Tip>(v, nullptr);

		if (kraj == nullptr)
		{
			// prazan red: novi cvor je i pocetak i kraj
			pocetak = novi;
			kraj = novi;
		}
		else
		{
			// stari kraj pokazuje na novi, pa novi postaje kraj
			kraj->next = novi;
			kraj = novi;
		}
		brojac++;
	}

	Tip ukloni() override
	{
		// 1. provjera: iz praznog reda nema sta ukloniti
		if (isPrazan())
		{
			throw runtime_error("RedPov::ukloni - red je prazan");
		}

		// 2. umanjenje brojaca
		brojac--;

		// 3. ukloni cvor s pocetka - adresu prvo sacuvaj u t
		Cvor<Tip>* t = pocetak;
		pocetak = pocetak->next;
		if (pocetak == nullptr)
			kraj = nullptr; // uklonjen je zadnji cvor - kraj vise ne postoji

		// 4. sacuvaj vrijednost PRIJE dealokacije, pa dealociraj cvor
		Tip x = t->info;
		delete t;

		// 5. vrati uklonjeni element
		return x;
	}

	bool isPrazan() override
	{
		return pocetak == nullptr;
	}

	int count() override
	{
		return brojac;
	}

	bool sadrzi(Tip v) override
	{
		Cvor<Tip>* t = pocetak;
		while (t != nullptr)
		{
			if (t->info == v)
				return true;
			t = t->next;
		}
		return false;
	}

	int ocistiSve() override
	{
		// svaki cvor mora biti dealociran - inace curenje memorije
		int b = 0;
		while (!isPrazan())
		{
			ukloni();
			b++;
		}
		return b;
	}

	void ispisi(string separator = "") override
	{
		Cvor<Tip>* t = pocetak;
		while (t != nullptr)
		{
			cout << t->info;
			if (t->next != nullptr)
				cout << separator;
			t = t->next;
		}
		cout << endl;
	}

	~RedPov()
	{
		while (pocetak != nullptr)
		{
			Cvor<Tip>* t = pocetak;
			pocetak = pocetak->next;
			delete t;
		}
	}
};
