#pragma once

#include <iostream>
#include <string>

using namespace std;

#include "TestFramework.h"
#include "Osoba.h"
#include "Stek.h"
#include "StekSekv.h"
#include "StekPov.h"

// ============================================================
//  Zajednicki testovi - vrijede za OBJE implementacije.
//  S je konkretna klasa: StekSekv<int> ili StekPov<int>.
// ============================================================
template <class S>
void testStekZajednicko(string oznaka)
{
	separator("TESTOVI " + oznaka);

	test(oznaka + " novi stek je prazan", [] {
		S s; return s.isPrazan() == true; });

	test(oznaka + " count() = 0 na praznom steku", [] {
		S s; return s.count() == 0; });

	test(oznaka + " nije prazan nakon push", [] {
		S s; s.push(10); return s.isPrazan() == false; });

	test(oznaka + " count() = 3 nakon 3x push", [] {
		S s; s.push(10); s.push(20); s.push(30);
		return s.count() == 3; });

	test(oznaka + " pop() vraca 30 (zadnji dodan - LIFO)", [] {
		S s; s.push(10); s.push(20); s.push(30);
		return s.pop() == 30; });

	test(oznaka + " pop() zatim vraca 20, pa 10", [] {
		S s; s.push(10); s.push(20); s.push(30);
		s.pop(); return s.pop() == 20 && s.pop() == 10; });

	test(oznaka + " prazan nakon svih pop()", [] {
		S s; s.push(10); s.push(20); s.push(30);
		s.pop(); s.pop(); s.pop();
		return s.isPrazan() == true && s.count() == 0; });

	test(oznaka + " pop() na praznom steku baca izuzetak", [] {
		S s; s.push(1); s.pop();
		bool bacen = false;
		try { s.pop(); }
		catch (...) { bacen = true; }
		return bacen; });

	test(oznaka + " push nakon pop: vrh je novi element", [] {
		S s; s.push(1); s.push(2); s.pop(); s.push(99);
		return s.count() == 2 && s.pop() == 99 && s.pop() == 1; });

	test(oznaka + " sadrzi(20) = true", [] {
		S s; s.push(10); s.push(20); s.push(30);
		return s.sadrzi(20) == true; });

	test(oznaka + " sadrzi(99) = false", [] {
		S s; s.push(10); s.push(20); s.push(30);
		return s.sadrzi(99) == false; });

	test(oznaka + " sadrzi() ne mijenja stek", [] {
		S s; s.push(10); s.push(20);
		s.sadrzi(10);
		return s.count() == 2 && s.pop() == 20; });

	test(oznaka + " sadrzi(30) = false nakon pop()", [] {
		S s; s.push(10); s.push(20); s.push(30);
		s.pop(); return s.sadrzi(30) == false; });

	test(oznaka + " ocistiSve() vraca 4 (broj obrisanih)", [] {
		S s; s.push(1); s.push(2); s.push(3); s.push(4);
		return s.ocistiSve() == 4; });

	test(oznaka + " prazan nakon ocistiSve()", [] {
		S s; s.push(1); s.push(2); s.push(3); s.push(4);
		s.ocistiSve(); return s.isPrazan() == true && s.count() == 0; });

	test(oznaka + " radi i nakon ocistiSve()", [] {
		S s; s.push(1); s.push(2); s.ocistiSve(); s.push(5);
		return s.count() == 1 && s.pop() == 5; });

	test(oznaka + " 100 elemenata: count() = 100", [] {
		S s;
		for (int i = 0; i < 100; i++) s.push(i);
		return s.count() == 100; });

	test(oznaka + " 100 elemenata: pop() vraca 99, 98 ... 0 (LIFO)", [] {
		S s;
		for (int i = 0; i < 100; i++) s.push(i);
		for (int i = 99; i >= 0; i--)
			if (s.pop() != i) return false;
		return s.isPrazan(); });
}

// ============================================================
//  Specificno za StekSekv: prosirenje niza
// ============================================================
void testStekSekvSpecificno()
{
	separator("TESTOVI [STEK-SEKV] - prosirenje");

	test("[STEK-SEKV] prosirenje: count() = 5 u steku kapaciteta 2", [] {
		StekSekv<int> s(2);
		for (int i = 1; i <= 5; i++) s.push(i * 10);
		return s.count() == 5; });

	test("[STEK-SEKV] prosirenje: LIFO ocuvan (pop = 50, pa 40)", [] {
		StekSekv<int> s(2);
		for (int i = 1; i <= 5; i++) s.push(i * 10);
		return s.pop() == 50 && s.pop() == 40; });

	test("[STEK-SEKV] prosirenje: i najstariji element ocuvan (dno = 10)", [] {
		StekSekv<int> s(2);
		for (int i = 1; i <= 5; i++) s.push(i * 10);
		int zadnji = 0;
		while (!s.isPrazan()) zadnji = s.pop();
		return zadnji == 10; });
}

// ============================================================
//  Vizuelna provjera ispisi() - nije automatski test.
//  Oba steka ispisuju ISTO: od vrha prema dnu.
// ============================================================
void ispisiStekVizuelno()
{
	separator("ispisi() - vizuelna provjera");
	try
	{
		StekSekv<int> s; s.push(10); s.push(20); s.push(30);
		cout << "  [STEK-SEKV] Ocekivano: 30, 20, 10" << endl;
		cout << "              Dobijeno:  ";
		s.ispisi(", ");
	}
	catch (...) { cout << "(nije implementirano)" << endl; }

	try
	{
		StekPov<int> p; p.push(10); p.push(20); p.push(30);
		cout << "  [STEK-POV]  Ocekivano: 30, 20, 10" << endl;
		cout << "              Dobijeno:  ";
		p.ispisi(", ");
	}
	catch (...) { cout << "(nije implementirano)" << endl; }
}

// ============================================================
//  Demo: ista funkcija radi s oba steka preko pokazivaca na interfejs
// ============================================================
void demoStekOsobe(Stek<Osoba*>* stek, string naziv)
{
	cout << "\n--- DEMO " << naziv << " (Stek<Osoba*>*) ---" << endl;

	Osoba* p21 = new Osoba(21, "p21");
	Osoba* p22 = new Osoba(22, "p22");
	Osoba* p23 = new Osoba(23, "p23");

	stek->push(p21);
	stek->push(p22);
	stek->push(p23);

	cout << "  ispisi (vrh -> dno): ";
	stek->ispisi("; ");

	while (!stek->isPrazan())
	{
		cout << "  pop {" << stek->pop() << "}" << endl;
	}

	// stek cuva samo ADRESE osoba - objekte brisemo mi
	delete p21; delete p22; delete p23;
	delete stek; // virtualni destruktor u Stek -> poziva ~StekSekv / ~StekPov
}

void _test_V02()
{
	testStekZajednicko<StekSekv<int>>("[STEK-SEKV]");
	testStekSekvSpecificno();

	testStekZajednicko<StekPov<int>>("[STEK-POV]");

	ispisiStekVizuelno();

	separator("DEMO - Stek<Osoba*>");
	try { demoStekOsobe(new StekSekv<Osoba*>, "StekSekv"); }
	catch (const exception& e) { cout << "  izuzetak: " << e.what() << endl; }
	try { demoStekOsobe(new StekPov<Osoba*>, "StekPov"); }
	catch (const exception& e) { cout << "  izuzetak: " << e.what() << endl; }

	rezultatTestova();
}
