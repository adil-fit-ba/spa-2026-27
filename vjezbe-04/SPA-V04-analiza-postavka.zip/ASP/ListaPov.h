#pragma once

#include "Lista.h"
#include "Cvor.h"

// Povezana lista (linked list): svaki element je u svom cvoru, cvorovi su vezani pokazivacem next.
// dodaj i ukloni rade na POCETKU liste, pa nema obilaska -> O(1).
//
//   prvi -> [30|*] -> [20|*] -> [10|nullptr]      (dodano redom 10, 20, 30)
template <class Tip>
class ListaPov : public Lista<Tip>
{
private:
	Cvor<Tip>* prvi;
	int brojac;

public:
	ListaPov()
	{
		prvi = nullptr;
		brojac = 0;
	}

	void dodaj(Tip v) override
	{
		// novi cvor pokazuje na dosadasnji prvi, pa tek onda postaje prvi
		Cvor<Tip>* novi = new Cvor<Tip>(v, prvi);
		prvi = novi;
		brojac++;
	}

	Tip ukloni() override
	{
		if (isPrazan())
		{
			throw runtime_error("ListaPov::ukloni - lista je prazna");
		}

		Cvor<Tip>* t = prvi;   // zapamti cvor koji brisemo
		Tip x = t->info;       // sacuvaj vrijednost (PRIJE delete)
		prvi = t->next;        // prvi prelazi na sljedeci (PRIJE delete)
		delete t;
		brojac--;
		return x;
	}

	bool isPrazan() override
	{
		return prvi == nullptr;
	}

	int count() override
	{
		// bez atributa brojac morali bismo obici cijelu listu -> O(n)
		return brojac;
	}

	Tip& get(int i) override
	{
		if (i < 0 || i >= brojac)
		{
			throw runtime_error("ListaPov::get - indeks izvan opsega");
		}

		// nema racunanja adrese kao kod niza - pratimo next i puta -> O(n)
		Cvor<Tip>* t = prvi;
		for (int b = 0; b < i; b++)
		{
			t = t->next;
		}
		return t->info;
	}

	bool sadrzi(Tip v) override
	{
		Cvor<Tip>* t = prvi;
		while (t != nullptr)
		{
			if (t->info == v)
				return true;
			t = t->next;
		}
		return false;
	}

	int ocistiSve() override
	{
		// svaki cvor mora biti dealociran - inace curenje memorije
		int b = 0;
		while (!isPrazan())
		{
			ukloni();
			b++;
		}
		return b;
	}

	void ispisi(string separator = "") override
	{
		Cvor<Tip>* t = prvi;
		while (t != nullptr)
		{
			cout << t->info;
			if (t->next != nullptr)
				cout << separator;
			t = t->next;
		}
		cout << endl;
	}

	~ListaPov()
	{
		while (prvi != nullptr)
		{
			Cvor<Tip>* t = prvi;
			prvi = prvi->next;
			delete t;
		}
	}
};
