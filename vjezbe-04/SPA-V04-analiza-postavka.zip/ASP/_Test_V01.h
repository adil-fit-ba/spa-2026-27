#pragma once

#include <iostream>
#include <string>

using namespace std;

#include "TestFramework.h"
#include "Osoba.h"
#include "Lista.h"
#include "ListaSekv.h"
#include "ListaPov.h"

// ============================================================
//  Zajednicki testovi - vrijede za OBJE implementacije.
//  L je konkretna klasa: ListaSekv<int> ili ListaPov<int>.
// ============================================================
template <class L>
void testListaZajednicko(string oznaka)
{
	separator("TESTOVI " + oznaka);

	test(oznaka + " nova lista je prazna", [] {
		L l; return l.isPrazan() == true; });

	test(oznaka + " count() = 0 na praznoj listi", [] {
		L l; return l.count() == 0; });

	test(oznaka + " nije prazna nakon dodaj", [] {
		L l; l.dodaj(10); return l.isPrazan() == false; });

	test(oznaka + " count() = 3 nakon 3x dodaj", [] {
		L l; l.dodaj(10); l.dodaj(20); l.dodaj(30);
		return l.count() == 3; });

	test(oznaka + " ukloni() vraca 30 (zadnji dodan)", [] {
		L l; l.dodaj(10); l.dodaj(20); l.dodaj(30);
		return l.ukloni() == 30; });

	test(oznaka + " ukloni() zatim vraca 20, pa 10", [] {
		L l; l.dodaj(10); l.dodaj(20); l.dodaj(30);
		l.ukloni(); return l.ukloni() == 20 && l.ukloni() == 10; });

	test(oznaka + " prazna nakon svih ukloni()", [] {
		L l; l.dodaj(10); l.dodaj(20); l.dodaj(30);
		l.ukloni(); l.ukloni(); l.ukloni();
		return l.isPrazan() == true && l.count() == 0; });

	test(oznaka + " ukloni() na praznoj listi baca izuzetak", [] {
		L l; l.dodaj(1); l.ukloni();
		bool bacen = false;
		try { l.ukloni(); }
		catch (...) { bacen = true; }
		return bacen; });

	test(oznaka + " sadrzi(20) = true", [] {
		L l; l.dodaj(10); l.dodaj(20); l.dodaj(30);
		return l.sadrzi(20) == true; });

	test(oznaka + " sadrzi(99) = false", [] {
		L l; l.dodaj(10); l.dodaj(20); l.dodaj(30);
		return l.sadrzi(99) == false; });

	test(oznaka + " sadrzi(30) = false nakon ukloni()", [] {
		L l; l.dodaj(10); l.dodaj(20); l.dodaj(30);
		l.ukloni(); return l.sadrzi(30) == false; });

	test(oznaka + " get(0) na listi s jednim elementom", [] {
		L l; l.dodaj(42); return l.get(0) == 42; });

	test(oznaka + " get(-1) baca izuzetak", [] {
		L l; l.dodaj(42);
		bool bacen = false;
		try { l.get(-1); }
		catch (...) { bacen = true; }
		return bacen && l.get(0) == 42; });

	test(oznaka + " get(count()) baca izuzetak (granica)", [] {
		L l; l.dodaj(42);
		bool bacen = false;
		try { l.get(1); }
		catch (...) { bacen = true; }
		return bacen && l.get(0) == 42; });

	test(oznaka + " get() vraca referencu - izmjena kroz get", [] {
		L l; l.dodaj(42);
		l.get(0) = 77;
		return l.sadrzi(77) == true && l.sadrzi(42) == false; });

	test(oznaka + " ocistiSve() vraca 4 (broj obrisanih)", [] {
		L l; l.dodaj(1); l.dodaj(2); l.dodaj(3); l.dodaj(4);
		return l.ocistiSve() == 4; });

	test(oznaka + " prazna nakon ocistiSve()", [] {
		L l; l.dodaj(1); l.dodaj(2); l.dodaj(3); l.dodaj(4);
		l.ocistiSve(); return l.isPrazan() == true && l.count() == 0; });

	test(oznaka + " radi i nakon ocistiSve()", [] {
		L l; l.dodaj(1); l.dodaj(2); l.ocistiSve(); l.dodaj(5);
		return l.count() == 1 && l.ukloni() == 5; });

	test(oznaka + " 100 elemenata: count() = 100", [] {
		L l;
		for (int i = 0; i < 100; i++) l.dodaj(i);
		return l.count() == 100; });

	test(oznaka + " 100 elemenata: ukloni() vraca 99, pa 98", [] {
		L l;
		for (int i = 0; i < 100; i++) l.dodaj(i);
		return l.ukloni() == 99 && l.ukloni() == 98; });
}

// ============================================================
//  Testovi koji se RAZLIKUJU: get(i) prati fizicki raspored.
//  ListaSekv: N[0] je prvi dodani.  ListaPov: prvi cvor je zadnji dodani.
// ============================================================
void testListaSekvSpecificno()
{
	separator("TESTOVI [SEKV] - specificno");

	test("[SEKV] get(0) = 10 (prvi dodani je u N[0])", [] {
		ListaSekv<int> l; l.dodaj(10); l.dodaj(20); l.dodaj(30);
		return l.get(0) == 10; });

	test("[SEKV] get(2) = 30", [] {
		ListaSekv<int> l; l.dodaj(10); l.dodaj(20); l.dodaj(30);
		return l.get(2) == 30; });

	test("[SEKV] prosirenje: count() = 5 u listi kapaciteta 2", [] {
		ListaSekv<int> l(2);
		for (int i = 1; i <= 5; i++) l.dodaj(i * 10);
		return l.count() == 5; });

	test("[SEKV] prosirenje: elementi ocuvani (get(0)=10, get(4)=50)", [] {
		ListaSekv<int> l(2);
		for (int i = 1; i <= 5; i++) l.dodaj(i * 10);
		return l.get(0) == 10 && l.get(4) == 50; });
}

void testListaPovSpecificno()
{
	separator("TESTOVI [POV] - specificno");

	test("[POV] get(0) = 30 (dodaj ide na pocetak)", [] {
		ListaPov<int> l; l.dodaj(10); l.dodaj(20); l.dodaj(30);
		return l.get(0) == 30; });

	test("[POV] get(2) = 10", [] {
		ListaPov<int> l; l.dodaj(10); l.dodaj(20); l.dodaj(30);
		return l.get(2) == 10; });
}

// ============================================================
//  Vizuelna provjera ispisi() - nije automatski test
// ============================================================
void ispisiVizuelno()
{
	separator("ispisi() - vizuelna provjera");
	try
	{
		ListaSekv<int> s; s.dodaj(10); s.dodaj(20); s.dodaj(30);
		cout << "  [SEKV] Ocekivano: 10, 20, 30" << endl;
		cout << "         Dobijeno:  ";
		s.ispisi(", ");
	}
	catch (...) { cout << "(nije implementirano)" << endl; }

	try
	{
		ListaPov<int> p; p.dodaj(10); p.dodaj(20); p.dodaj(30);
		cout << "  [POV]  Ocekivano: 30, 20, 10" << endl;
		cout << "         Dobijeno:  ";
		p.ispisi(", ");
	}
	catch (...) { cout << "(nije implementirano)" << endl; }
}

// ============================================================
//  Demo: ista funkcija radi s obje liste preko pokazivaca na interfejs
// ============================================================
void demoOsobe(Lista<Osoba*>* lista, string naziv)
{
	cout << "\n--- DEMO " << naziv << " (Lista<Osoba*>*) ---" << endl;

	Osoba* p21 = new Osoba(21, "p21");
	Osoba* p22 = new Osoba(22, "p22");
	Osoba* p23 = new Osoba(23, "p23");
	Osoba* p24 = new Osoba(24, "p24");
	Osoba* p25 = new Osoba(25, "p25");

	lista->dodaj(p21);
	lista->dodaj(p22);

	Osoba* pZadnji = lista->ukloni();
	cout << "  uklonjen {" << pZadnji << "}" << endl;

	lista->dodaj(p23);
	lista->dodaj(p24);
	lista->dodaj(p25);

	cout << "  ispisi: ";
	lista->ispisi("; ");

	for (int i = 0; i < lista->count(); i++)
	{
		cout << "  lista[" << i << "] = " << lista->get(i) << endl;
	}

	while (!lista->isPrazan())
	{
		cout << "  uklonjen {" << lista->ukloni() << "}" << endl;
	}

	// lista cuva samo ADRESE osoba - objekte brisemo mi
	delete p21; delete p22; delete p23; delete p24; delete p25;
	delete lista; // virtualni destruktor u Lista -> poziva ~ListaSekv / ~ListaPov
}

void _test_V01()
{
	testListaZajednicko<ListaSekv<int>>("[SEKV]");
	testListaSekvSpecificno();

	testListaZajednicko<ListaPov<int>>("[POV]");
	testListaPovSpecificno();

	ispisiVizuelno();

	separator("DEMO - Lista<Osoba*>");
	try { demoOsobe(new ListaSekv<Osoba*>, "ListaSekv"); }
	catch (const exception& e) { cout << "  izuzetak: " << e.what() << endl; }
	try { demoOsobe(new ListaPov<Osoba*>, "ListaPov"); }
	catch (const exception& e) { cout << "  izuzetak: " << e.what() << endl; }

	rezultatTestova();
}
